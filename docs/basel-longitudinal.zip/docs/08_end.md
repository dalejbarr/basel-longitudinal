# Going further

Here are my [slides](slides/08_end/index.html) giving a brief overview of generalized linear mixed effects models (GLMMs), generalized additive mixed models (GAMMs), and generalized life hacks.

Before you leave, be sure to check out [my suggestions for further reading in Appendix C!](references-and-further-reading.html#further-reading) and [download an offline copy of these materials](basel-longitudinal.zip) for safekeeping! Godspeed!
